import math

def distance_3d(a, b):
    return math.sqrt((a['x'] - b['x']) ** 2 + (a['y'] - b['y']) ** 2 + (a.get('z', 0) - b.get('z', 0)) ** 2)

def check_spatial_conflict(primary_wp, other_wp, buffer):
    return distance_3d(primary_wp, other_wp) < buffer

def check_temporal_overlap(t1_start, t1_end, t2_start, t2_end):
    return max(t1_start, t2_start) < min(t1_end, t2_end)

def check_conflicts(primary, others, buffer=10):
    conflicts = []
    for flight_id, flight in enumerate(others):
        for i, primary_wp in enumerate(primary['waypoints']):
            for j, other_wp in enumerate(flight['waypoints']):
                if check_spatial_conflict(primary_wp, other_wp, buffer):
                    if check_temporal_overlap(primary['time_window'][0], primary['time_window'][1],
                                              flight['time_window'][0], flight['time_window'][1]):
                        conflicts.append({
                            'conflict_with': f"Flight {flight_id}",
                            'location': {
                                'x': primary_wp['x'],
                                'y': primary_wp['y'],
                                'z': primary_wp.get('z', 0)
                            },
                            'time_window': [
                                max(primary['time_window'][0], flight['time_window'][0]),
                                min(primary['time_window'][1], flight['time_window'][1])
                            ]
                        })
    return conflicts