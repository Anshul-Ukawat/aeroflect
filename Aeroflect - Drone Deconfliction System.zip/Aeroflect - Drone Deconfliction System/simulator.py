def simulate_path(waypoints, time_window):
    start_time, end_time = time_window
    total_duration = end_time - start_time
    num_segments = len(waypoints) - 1
    if num_segments <= 0:
        return []

    time_per_segment = total_duration / num_segments
    simulated = []

    for i in range(num_segments):
        wp_start = waypoints[i]
        wp_end = waypoints[i + 1]
        for step in range(11):  # 10 steps per segment
            fraction = step / 10
            x = wp_start['x'] + (wp_end['x'] - wp_start['x']) * fraction
            y = wp_start['y'] + (wp_end['y'] - wp_start['y']) * fraction
            z = wp_start.get('z', 0) + (wp_end.get('z', 0) - wp_start.get('z', 0)) * fraction
            timestamp = start_time + (i + fraction) * time_per_segment
            simulated.append({'x': x, 'y': y, 'z': z, 't': timestamp})

    return simulated
