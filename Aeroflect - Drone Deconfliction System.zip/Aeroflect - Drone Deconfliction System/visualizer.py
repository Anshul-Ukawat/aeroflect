import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import matplotlib.animation as animation

def plot_2d(primary_path, other_paths, conflicts=[]):
    plt.figure(figsize=(10, 6))
    plt.title("2D Drone Trajectories with Conflict Zones")

    px = [p['x'] for p in primary_path]
    py = [p['y'] for p in primary_path]
    plt.plot(px, py, 'b-o', label='Primary Drone')

    for i, path in enumerate(other_paths):
        ox = [p['x'] for p in path]
        oy = [p['y'] for p in path]
        plt.plot(ox, oy, '--', label=f'Simulated Drone {i+1}')

    for c in conflicts:
        plt.plot(c['x'], c['y'], 'rx', markersize=10)

    plt.xlabel("X")
    plt.ylabel("Y")
    plt.legend()
    plt.grid(True)
    plt.show()

def plot_3d(primary_path, other_paths, conflicts=[]):
    fig = plt.figure(figsize=(10, 7))
    ax = fig.add_subplot(111, projection='3d')
    ax.set_title("3D Drone Paths with Conflicts")

    px = [p['x'] for p in primary_path]
    py = [p['y'] for p in primary_path]
    pz = [p['z'] for p in primary_path]
    ax.plot(px, py, pz, 'b-o', label='Primary Drone')

    for i, path in enumerate(other_paths):
        ox = [p['x'] for p in path]
        oy = [p['y'] for p in path]
        oz = [p['z'] for p in path]
        ax.plot(ox, oy, oz, '--', label=f'Simulated Drone {i+1}')

    for c in conflicts:
        ax.scatter(c['x'], c['y'], c['z'], c='r', s=50)

    ax.set_xlabel("X")
    ax.set_ylabel("Y")
    ax.set_zlabel("Z")
    ax.legend()
    plt.show()

def animate_4d(paths_with_time):
    fig = plt.figure()
    ax = fig.add_subplot(111, projection='3d')
    ax.set_xlim([0, 100])
    ax.set_ylim([0, 100])
    ax.set_zlim([0, 100])

    scatters = []
    for _ in paths_with_time:
        scatters.append(ax.plot([], [], [], 'o')[0])

    def update(frame):
        for i, path in enumerate(paths_with_time):
            coords = [(p['x'], p['y'], p['z']) for p in path if p['t'] == frame]
            if coords:
                x, y, z = zip(*coords)
                scatters[i].set_data(x, y)
                scatters[i].set_3d_properties(z)
        return scatters

    ani = animation.FuncAnimation(fig, update, frames=range(0, 100), interval=200, blit=False)
    plt.title("4D Drone Path Animation (Time Evolution)")
    plt.show()