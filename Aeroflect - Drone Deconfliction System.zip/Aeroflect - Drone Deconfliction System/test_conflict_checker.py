import unittest
from conflict_checker import detect_conflicts

class TestConflictChecker(unittest.TestCase):

    def setUp(self):
        self.primary = {
            'waypoints': [
                {'x': 0, 'y': 0, 'z': 0},
                {'x': 10, 'y': 10, 'z': 0}
            ],
            'time_window': (0, 10)
        }

    def test_no_conflict(self):
        others = [
            {
                'waypoints': [
                    {'x': 50, 'y': 50, 'z': 0},
                    {'x': 60, 'y': 60, 'z': 0}
                ],
                'time_window': (0, 10)
            }
        ]
        result = detect_conflicts(self.primary, others)
        self.assertEqual(result['status'], 'clear')

    def test_spatial_conflict(self):
        others = [
            {
                'waypoints': [
                    {'x': 5, 'y': 5, 'z': 0},
                    {'x': 15, 'y': 15, 'z': 0}
                ],
                'time_window': (0, 10)
            }
        ]
        result = detect_conflicts(self.primary, others)
        self.assertEqual(result['status'], 'conflict')
        self.assertTrue('conflicts' in result)

    def test_temporal_conflict_only(self):
        others = [
            {
                'waypoints': [
                    {'x': 5, 'y': 5, 'z': 0},
                    {'x': 15, 'y': 15, 'z': 0}
                ],
                'time_window': (20, 30)  # Non-overlapping time
            }
        ]
        result = detect_conflicts(self.primary, others)
        self.assertEqual(result['status'], 'clear')

    def test_edge_overlap(self):
        others = [
            {
                'waypoints': [
                    {'x': 10, 'y': 10, 'z': 0},
                    {'x': 20, 'y': 20, 'z': 0}
                ],
                'time_window': (10, 20)  # Overlaps exactly at the end
            }
        ]
        result = detect_conflicts(self.primary, others)
        self.assertEqual(result['status'], 'conflict')

if __name__ == '__main__':
    unittest.main()