import numpy as np
import pickle
from sklearn.ensemble import RandomForestClassifier

class AIConflictPredictor:
    def __init__(self, model_path):
        try:
            with open(model_path, 'rb') as f:
                self.model = pickle.load(f)
        except FileNotFoundError:
            print("[Warning] AI model not found. Using mock prediction.")
            self.model = None

    def extract_features(self, primary, others):
        features = []
        for flight in others:
            for i in range(len(primary['waypoints'])):
                wp1 = primary['waypoints'][i]
                t1_start, t1_end = primary['time_window']

                for j in range(len(flight['waypoints'])):
                    wp2 = flight['waypoints'][j]
                    t2_start, t2_end = flight['time_window']

                    dx = wp1['x'] - wp2['x']
                    dy = wp1['y'] - wp2['y']
                    dz = wp1.get('z', 0) - wp2.get('z', 0)
                    dist = np.sqrt(dx**2 + dy**2 + dz**2)
                    time_overlap = max(0, min(t1_end, t2_end) - max(t1_start, t2_start))

                    features.append([dist, time_overlap])
        return np.mean(features, axis=0).reshape(1, -1) if features else np.zeros((1, 2))

    def predict_conflict(self, primary, others):
        features = self.extract_features(primary, others)
        if self.model:
            return bool(self.model.predict(features)[0])
        else:
            # Mock: Predict conflict if distance < 20 and time_overlap > 2
            return features[0][0] < 20 and features[0][1] > 2
